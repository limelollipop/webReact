import './scss/style.scss';

function App() {
	const box = {
		width: 100,
		height: 100,
		backgroundColor: 'gray',
		margin: 50,
	}; // 배열은 성격이 같은 애들을 묶어둔 것, 객체는 성격이 다른 애들을 한 가지의 주제로 묶은 것

	const circle = {
		width: 200,
		height: 200,
		borderRadius: '50%',
		backgroundColor: '#eee',
		margin: 20,
	};

	/* 해당함수를 외부에서 만들어서 retun안에 대입
		onClick이란 이벤트는 화살표함수()=>{} 로 받는다
	*/
	const changeBg = (e, color) => {
		e.target.style.backgroundColor = color;
	};
	const chageBorder = (e, border) => {
		e.target.style.borderRadius = border;
	};

	return (
		<div className='wrap'>
			<article
				style={circle}
				onClick={(e) => {
					chageBorder(e, '0%');
				}}
			></article>

			<article
				style={box}
				onClick={(e) => {
					changeBg(e, 'hotpink');
				}}
			></article>

			<article
				style={box}
				onClick={(e) => {
					changeBg(e, 'lightSkyBlue');
				}}
			></article>

			{/* <article style={box} onClick={(e) => {changeBg(e, 'green')}}></article> */}
			<article
				style={box}
				onClick={(e) => {
					changeBg(e, 'green');
				}}
			></article>
			<article
				style={box}
				onClick={(e) => {
					changeBg(e, 'yellow');
				}}
			></article>
		</div>
	);
}

export default App;

/*
이벤트 객체란
DOM과 관련된 이벤트가 발생하면 관련된 정보는 모두 event 객체에 저장됨
이벤트 발생요소/타입 등 관련된 데이터가 만들어지고 
이것을 사용할 때 첫번째 매개변수를 명시적으로 선언해야한다

이벤트 객체 동적으로 생성되어 이벤트 핸들러에 인자로 전달됨
명시적으로 선언해줘야 한다
------------------------------------

onClick 이벤트란
리액트는 onClick이고 js는 onclick
리액트는 js문법을 사용하므로 {}를 사용해야하고, js는 ""문자열로 해당 함수나 값을 받기만 하면된다
리액트의 onClick이벤트는 오직 하나의 함수만 받을 수 있다. 반면 js의 onclick은 여러개의 함수를 받을 수 있다

vanila js
<button onclick ="some()";></botton>

react
<button onClick = {some()}></botton>
*/

/*
가상DOM과 리얼DOM
쿼리셀렉터는 리액터에서는 '제한'
document.querySelector는 사용 하면 안 됨
왜냐면 가상돔으로 만든 요소들은 리얼돔에서 사용하는 document.querySelector는 이미 리얼돔으로 진행된 상태를 의미

리액트는 가상돔에서 요소를 만들고 이전 돔과 비교해서 변화된 내용을 리얼돔으로 구현하는 시스템이기때문에 document를 사용하면 충돌의 위험성이 아주 크다

쿼리셀렉터는 사용해도 되는가?
쿼리셀렉터는 대상을 참조한다는 뜻이다
우선 리액트에서는 대상을 참조하는 훅이 존재 → useRef
그래서 리액트에서는 대상을 참조할 때 useRef를 추천

→ 리액트 생명주기때문에 querySelector와 useRef를 각각 사용할 때가 있음
	쿼리셀렉터는 참조방법이 리액트의 구성과 맞지않아 비추천

	useRef의 경우 언마운트 되어야하는 대상을 참조할 경우 언마운트가 안 됨

☆ 보통은 useRef를 사용하여 대상을 참조하고, 특별한 경우(생명주기와 연관된)에만 쿼리셀렉터를 사용한다
	*/
