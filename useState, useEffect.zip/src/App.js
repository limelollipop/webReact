import { useEffect, useState } from 'react';

function App() {
	const [count, setCount] = useState(1);
	const [name, setName] = useState('');

	function update() {
		setCount(count + 1);
	}

	useEffect(() => {
		console.log('랜더링 시, 실행');
	});

	useEffect(() => {
		console.log('카운트 랜더링 시, 실행');
	}, [count]);
	// [count] 할 때만 랜더링이 일어나면 실행해라

	useEffect(() => {
		console.log('이름 랜더링 시, 실행');
	}, [name]);

	function inputUpdate(e) {
		setName(e.target.value);
	}

	return (
		<div>
			<span>count : {count}</span>
			<button onClick={update}>Update</button>

			<input type='text' value={name} onChange={inputUpdate} />
			<span>name : {name}</span>
		</div>
	);
}

export default App;
/*
랜더링이 일어나면 실행하는 함수 useEffect, 아래 3종류 있음

useEffect(()=>{작업});
하나의 매개변수로 콜백함수 하나만 받는경우
→ 매 랜더링이 될 때마다 작업이 실행된다

useEffect(()=>{	작업}, []);
두개의 매개변수로 콜백함수와 배열(dependency array)를 받는 경우
→ 처음 랜더링 될 때만 실행함
만약 디펜던시어레이가 빈배열이라면?
→ 디펜던시어레이 값이 업데이트 될 때무다 작업이 실행된다


알아만 두기
useEffect(()=>{
	작업
		return (
			클린업 함수 → 정리하는 작업, 언마운트 될 때 사용함
		);
	}, {input});
	콜백함수 안에 리턴으로 클린업 함수가 있는 경우
	→ 해당 작업이 끝나고, return안의 클린업 함수가 실행하면서 언마운트 시킴
*/

//--------------------------------------------
// import { useState } from 'react';

// function App() {
// 	// 아래는 비구조화 할당 useState(초기값세팅);
// 	const [time, setTime] = useState(3);

// 	/*
// useState 사용방법
// 1. react로부터 import한다
// 2. 비구조화 할당으로 useState를 선언한다.
// 	이때 const [결과값(배열값), set 함수(결과값을 변경할 수 있는 유일한 함수)] = useState(초기값);
// 3. 변화되는 지점에 결과값의 변수를 지정하고, 랜더링이 일어나야할 지점에 set 함수를 설정해서 특정 이벤트가 발생하면 set 함수를 발동해서 결과값을 변화시키고 그 변화를 인지한 리액트는 화면을 재 랜더링하여 업데이트 한다
// */

// 	function UpTime() {
// 		setTime(time + 1);
// 	}

// 	return (
// 		<div>
// 			<span>현재 시각 : {time}시</span>
// 			<button onClick={UpTime}>Update</button>
// 		</div>
// 	);
// }

// export default App;
