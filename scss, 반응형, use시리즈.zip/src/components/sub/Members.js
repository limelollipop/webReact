import Layout from '../common/Layout';

export default function Members() {
	return (
		<Layout name={'Membership'}>
			<p>Members Content</p>
		</Layout>
	);
}
