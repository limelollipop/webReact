import Layout from '../common/Layout';

function Gallery() {
	return (
		<Layout name={'Gallery'}>
			<p>Gallery Content</p>
		</Layout>
	);
}

export default Gallery;
