import Layout from '../common/Layout';

function Location() {
	return (
		<Layout name={'Location'}>
			<p>Location Content</p>
		</Layout>
	);
}

export default Location;
