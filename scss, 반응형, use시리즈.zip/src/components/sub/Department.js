import Layout from '../common/Layout';

function Department() {
	return (
		<Layout name={'Department'}>
			<p>Department Content</p>
		</Layout>
	);
}

export default Department;
