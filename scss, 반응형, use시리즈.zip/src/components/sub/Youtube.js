import Layout from '../common/Layout';

function Youtube() {
	return (
		<Layout name={'Youtube'}>
			<p>Youtube Content</p>
		</Layout>
	);
}

export default Youtube;
