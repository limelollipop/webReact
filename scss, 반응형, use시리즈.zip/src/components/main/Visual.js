function Visual() {
	return <figure id='visual'></figure>;
}

export default Visual;
