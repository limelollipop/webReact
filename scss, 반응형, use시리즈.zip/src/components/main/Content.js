function Content() {
	return (
		<main>
			<h1>Content</h1>
		</main>
	);
}

export default Content;
